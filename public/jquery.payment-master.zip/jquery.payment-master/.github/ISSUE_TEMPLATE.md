<!-- Thanks for your interest in contributing! jquery.payment is deprecated. Please see "Project Status" in the README. -->
